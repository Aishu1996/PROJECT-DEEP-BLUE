#create a horizontal header file.
import csv
from time import gmtime, strftime

x = 'App1'
y = strftime("%d-%b-%y", gmtime())+'.csv'
pwd = 'F:/AArti/xampp/htdocs/ocr13'
path_csv = pwd+'/config/'+x+'.csv'

with open(path_csv,'r') as csv_file:
    csv_reader = csv.reader(csv_file,delimiter='~')    
    next(csv_reader)
    list = []
    for line in csv_reader:
        temp = line[0]
        list.append(temp)
#naming output file
file = 'F:/AArti/xampp/htdocs/ocr13/output/'+x+'_'+y
with open(file,"w") as f:
    wr = csv.writer(f,delimiter="~")
    wr.writerow(list)