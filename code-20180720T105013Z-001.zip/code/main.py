import csv
from PIL import Image
import pytesseract

#form_type = sys.argv[1] # Which form
#image_name = sys.argv[2] # Image name
form_type = "APP3"
image_name = "APP3_form031.jpg"
path_pwd = 'F:/AArti/xampp/htdocs/ocr13'
path_csv = path_pwd + '/input/' + form_type + '/'
path_image = path_pwd + '/input/' + form_type + '/'
path_temp = path_pwd + '/temp/'
path_config = path_pwd + '/config/' + form_type + '.csv'
#pytesseract.pytesseract.tesseract_cmd ='C:/Users/Girisha/Desktop/ocr/Tesseract-OCR/tesseract'

img = Image.open(path_image + image_name) 

with open(path_config, 'rb') as f:
    mycsv = csv.reader(f, delimiter="~")
    mycsv = list(mycsv)
    row = len(mycsv)
    for line_number in range(1,row):
        area = (mycsv[line_number][1] , mycsv[line_number][4] , mycsv[line_number][3],mycsv[line_number][2])
        img_cropped = img.crop([int(y) for y in area])
        img_cropped.save(path_temp+'img_cropped.png')
        if(mycsv[line_number][5] == "digits"):
            text = pytesseract.image_to_string(Image.open(path_temp+ "img_cropped.png"),lang='qq',config='digits')
        elif(mycsv[line_number][5]=="string"):
            text = pytesseract.image_to_string(Image.open(path_temp+ "img_cropped.png"),lang='qq',config='strings')
        elif(mycsv[line_number][5]=="date"):
            text = pytesseract.image_to_string(Image.open(path_temp+ "img_cropped.png"),lang='qq',config='date')
        elif(mycsv[line_number][5]=="mail"):
            text = pytesseract.image_to_string(Image.open(path_temp+ "img_cropped.png"),lang='qq',config='mail')
        else:
            text = pytesseract.image_to_string(Image.open(path_temp+ "img_cropped.png"),lang='qqq')
        
        fs = open(path_temp + 'value.csv', 'a')
        fs.write(text + '~')
        fs.close()
        

