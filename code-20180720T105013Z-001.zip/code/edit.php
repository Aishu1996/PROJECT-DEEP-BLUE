<!DOCTYPE html>
<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">	
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="/resources/demos/style.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<script>
			$(document).ready(function(){
			$("button").click(function( ){
				var file_text;
				file_text = $( "#y1f_1" ).text( );
				$.post( "val.php", {file_data : file_text} , function( data ){
					alert("Successfully Saved!" );
				});
			});
			});
		</script>
	</head>
	<style>
		body {background-color: #262626;}
		.button {
			background-color: #262626;
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			border-radius: 10px;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
		}
		table, th, td {
			border: 1px solid black;
			border-collapse:collapse; 
		}
		.uploads{
		    margin: auto;
		    margin-top:5%;
			width: 60%;
		    height: 300px;
			border: 3px solid gray;
			border-radius: 18px;
			padding: 75px;
			text-align: center;
			background: #f2f2f2;
		    padding: 75px;
		    box-shadow: 1px 1px 1px 1px #888888;
		}  
		.skewedBox{
			background: #708090;
			padding: 80px 0;
		}
	</style>
	<body>
		<section class="skewedBox">
			<div class="container">
			</div>
		</section>
		<div class="uploads">
		  <?php
			// Create a table from a csv file 
			echo "<table align='center' cellpadding='20'>\n\n";
			$form_type = $_GET['radioVal'];
			#$form_type = 'APP1';
			echo($form_type);
			$row = 1;
			$path_pwd = 'F:/AArti/xampp/htdocs/ocr13';
			$path_temp = $path_pwd.'/temp/value.csv';
			$path_config = $path_pwd.'/config'.'/'.$form_type.'.csv';
			if (($handle = fopen($path_config, "r")) !== FALSE) {
				 echo "<tr>";
				 while (($data = fgetcsv($handle, 1000, "~")) !== FALSE) { 
				    echo "<td>" . ' ' . $data[0] . "</td>" ;
				}
				 echo "</tr>";
				 fclose($handle);
			}
			$f = fopen($path_temp, "r");
			while (($line = fgetcsv($f)) !== false) {
					$row = $line[0];    // We need to get the actual row (it is the first element in a 1-element array)
					$cells = explode("~",$row);
					echo "<tr id='y1f_1'>";
					foreach ($cells as $cell) {
						echo "<td contenteditable='true'>" . htmlspecialchars($cell). "\t"  . "</td>";
					}
					echo "</tr>\n";
			}
			fclose($f);
			echo "\n</table>";
		  ?>
		  </br><button onclick="location.href='form.php';">
		     <span title="save" class="glyphicon glyphicon-save">SAVE</span>
		  </button>
		  <button onclick="location.href='form.php';" >
		     <span title="cancel">CANCEL</span>
		  </button>
		</div>
	</body>
</html>