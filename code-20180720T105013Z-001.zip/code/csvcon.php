<?php
	$handle = fopen("data.txt", "r");
	$lines = [];
	if (($handle = fopen("data.txt", "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
			$lines[] = $data;
		}
	    fclose($handle);
	}
	$fp = fopen('file.csv', 'w');
	foreach ($lines as $line) {
		fputcsv($fp, $line);
	}
	fclose($fp);
?>