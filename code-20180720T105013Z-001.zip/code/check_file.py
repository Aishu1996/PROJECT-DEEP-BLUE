import os.path
import os 
from time import gmtime, strftime

x = 'App1'
y = strftime("%d-%b-%y", gmtime())+'.csv'

path_pwd = 'F:/AArti/xampp/htdocs/ocr13/code/main.py'
file = path_pwd+'/'+x+'_'+y

if(not(os.path.isfile(file))):
    os.system('python F:/AArti/xampp/htdocs/ocr13/code/try2.py')
os.system('python F:/AArti/xampp/htdocs/ocr13/code/append_csv.py')