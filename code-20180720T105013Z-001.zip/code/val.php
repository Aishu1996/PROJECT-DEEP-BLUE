<?php
	echo file_put_contents( "data.txt", $_POST[ "file_data" ] );
?>