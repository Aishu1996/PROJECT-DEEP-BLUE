import csv  
import os
from time import gmtime, strftime

x = 'App1'
y = strftime("%d-%b-%y", gmtime())+'.csv'
pwd = 'F:/AArti/xampp/htdocs/ocr13'
path_csv = pwd+'/code/file.csv'
file = 'F:/AArti/xampp/htdocs/ocr13/output/'+x+'_'+y
with open(path_csv,'r') as csv_file:
    csv_reader = csv.reader(csv_file,delimiter=',')

    with open(file, 'ab') as f:
        writer = csv.writer(f,delimiter='~')
            
        for line in csv_reader:   
            writer.writerow(line)